//ANDREA BARBIN 3°E ES 1 

/*Scrivere un programma in C che dopo aver letto N numeri calcoli la somma solo
dei numeri maggiori di 5.*/

#include<stdio.h>
void main (void){
//INIZIO

//DICHIARAZIONE DELLE VARIABILI
int numeroAddendi, addendo, i; //La variabile i costituisce il contatore necessario a bloccare l'iterazione indefinita
                               // La variabile addendo infica gli addendi che andranno ogni volta letti in input.
float somma;
printf("Inserire il numero di addendi che si desidera sommare.\n");
scanf("%d",&numeroAddendi);

//ELABORAZIONE DATI
do {

    //FASE DI INPUT   
    printf("Inserisci un addendo\n");
    scanf("%f",&addendo);
    if (addendo>5)
    {
    somma=somma+addendo;
    }
    i++;
} while (i<numeroAddendi&&addendo>5);

//FASE DI OUTPUT
printf("La somma tra numeri reali è %2f \n",somma);

//FINE
} 