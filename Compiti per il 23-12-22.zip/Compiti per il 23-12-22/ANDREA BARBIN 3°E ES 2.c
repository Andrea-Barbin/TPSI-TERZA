//ANDREA BARBIN 3°E ES 2 
/*Scrivere un programma in C che dopo aver letto N numeri calcoli la somma solo
dei numeri pari e la media solo dei numeri dispari.*/

#include <stdio.h>
void main()
{
    //INIZIO
    //DICHIARAZIONE DELLE VARIABILI
    int numeriDaEsaminare, numero, i ;   //La variabile i costituisce il contatore necessario a bloccare l'iterazione indefinita
    float somma = 0, media = 0; 
    
    printf("Quanti numeri desideri esaminare?\n");
    scanf("%d", &numeriDaEsaminare);
    
    //FASE DI ELABORAZIONE 
    do
    {
        printf("Inserire il numero\n");
        scanf("%d", &numero);


        if (numero %2==0)
        {
           somma = somma + numero;
        }
        if (numero %2 != 0)
        { 
        media = media + numero;
        }
        i++;
        numeriDaEsaminare++;
    } while (i==numeriDaEsaminare);

    //FASE DI OUTPUT
    printf("La somma è: %f\n", somma);
    printf("La media è: %f\n", media);

    //FINE
}